RIDWAN SHOP ONLINE — PANDUAN PENERBITAN
=======================================

PENTING
- Paket ini sudah disiapkan untuk hosting online.
- Saya tidak bisa menerbitkannya ke internet dari akun hosting Anda. Anda perlu membuat akun Render dan JSONBin, lalu memasukkan kredensial ke Environment Variables Render.
- Jangan pernah menaruh JSONBin Master Key di index.html atau membagikannya di chat.
- Buat API key JSONBin baru. API key lama pernah tertanam di HTML lama, jadi sebaiknya dicabut.

ISI PAKET
- public/index.html : tampilan website RIDWAN SHOP
- server.js         : backend, login admin, sinkronisasi cloud, validasi pesanan
- seed.json         : data awal produk toko untuk record JSONBin
- render.yaml       : konfigurasi deployment Render

LANGKAH 1 — BUAT DATA JSONBIN
1. Masuk ke https://jsonbin.io/ dan buat akun.
2. Buat API Key baru (Master Key). Simpan secara pribadi.
3. Buat JSON Bin baru dengan isi file seed.json.
4. Salin Bin ID dari halaman bin.
5. Jangan gunakan Master Key lama yang pernah ada di HTML lama.

LANGKAH 2 — UPLOAD KE GITHUB
1. Ekstrak ZIP ini.
2. Buat repository baru di https://github.com/.
3. Upload seluruh isi folder ridwan-shop-online ke repository (pastikan server.js, package.json, render.yaml, dan folder public ikut ter-upload).

LANGKAH 3 — DEPLOY KE RENDER
1. Masuk ke https://render.com/ dan daftar/login.
2. Pilih New + → Blueprint.
3. Hubungkan repository GitHub tadi.
4. Render akan membaca render.yaml dan membuat Web Service.
5. Isi tiga Environment Variables saat diminta:
   JSONBIN_BIN_ID       = Bin ID dari langkah 1
   JSONBIN_MASTER_KEY   = Master Key BARU dari JSONBin
   ADMIN_PASSWORD       = password admin awal yang kuat (minimal 12 karakter)
6. Klik deploy dan tunggu sampai status Live.
7. Buka URL Render yang diberikan. Itulah alamat website online Anda.

CARA LOGIN ADMIN
- Username: admin
- Password: nilai ADMIN_PASSWORD yang Anda masukkan di Render.
- Setelah login, password dapat diubah dari menu pengaturan admin (minimal 12 karakter).

FITUR ONLINE
- Pengunjung dapat melihat produk dari cloud dan membuat pesanan.
- Pesanan disimpan ke JSONBin melalui backend, stok dikurangi di server.
- Admin dapat mengelola produk, pesanan, keuangan, dan pengaturan toko.
- Master Key JSONBin hanya berada di server, tidak di browser.
- Data admin tidak dikirim ke pengunjung umum.
- Konflik perubahan antarperangkat dideteksi dengan revision check; bila terjadi, muat ulang data dan ulangi perubahan.

CATATAN
- Render free dapat tidur saat tidak dipakai; kunjungan pertama setelah lama tidak aktif bisa lebih lambat.
- Gunakan satu instance server (default Render) agar antrean mutasi server tetap berurutan.
- Sebelum deploy, isi record JSONBin dengan seed.json.
- Backup data secara berkala melalui fitur Backup di dashboard admin.
