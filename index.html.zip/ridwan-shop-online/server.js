const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const path = require('path');

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '8mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
const BIN_ID = process.env.JSONBIN_BIN_ID;
const MASTER_KEY = process.env.JSONBIN_MASTER_KEY;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const sessions = new Map();
const SESSION_TTL = 12 * 60 * 60 * 1000;
let writeQueue = Promise.resolve();

if (!BIN_ID || !MASTER_KEY || !ADMIN_PASSWORD) {
  console.error('Missing required env vars: JSONBIN_BIN_ID, JSONBIN_MASTER_KEY, ADMIN_PASSWORD');
  process.exit(1);
}
if (ADMIN_PASSWORD.length < 12) {
  console.error('ADMIN_PASSWORD must be at least 12 characters.');
  process.exit(1);
}

const defaultData = {
  storeName: 'RIDWAN SHOP', storeLogo: '🌾',
  storeAddress: 'Ciketing Udik, RT 02/05, Jl. Rawa Butun',
  storePhone: '087875112614', storeMapCoord: '-6.3475,106.9922',
  products: [], orders: [], finance: [], trashBin: [], _revision: 0
};

async function jsonbinRequest(method, body) {
  const url = method === 'GET'
    ? `https://api.jsonbin.io/v3/b/${BIN_ID}/latest`
    : `https://api.jsonbin.io/v3/b/${BIN_ID}`;
  const response = await fetch(url, {
    method,
    headers: { 'X-Master-Key': MASTER_KEY, 'Content-Type': 'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  if (!response.ok) {
    const details = await response.text().catch(() => '');
    throw new Error(`JSONBin ${method} failed (${response.status}): ${details.slice(0, 250)}`);
  }
  return response.json();
}

async function readData() {
  const result = await jsonbinRequest('GET');
  const record = result && result.record;
  if (!record || typeof record !== 'object' || Array.isArray(record)) throw new Error('JSONBin record is not a JSON object.');
  return { ...defaultData, ...record, _revision: Number(record._revision || 0) };
}

async function writeData(data) {
  await jsonbinRequest('PUT', data);
}

function mutateData(mutator) {
  const task = writeQueue.then(async () => {
    const latest = await readData();
    const changed = await mutator(latest);
    changed._revision = latest._revision + 1;
    changed.updatedAt = new Date().toISOString();
    await writeData(changed);
    return changed;
  });
  writeQueue = task.catch(() => {});
  return task;
}

function tokenFrom(req) {
  const header = req.get('authorization') || '';
  return header.startsWith('Bearer ') ? header.slice(7) : '';
}
function isAdmin(req) {
  const token = tokenFrom(req);
  const expiry = sessions.get(token);
  if (!token || !expiry || expiry < Date.now()) {
    if (token) sessions.delete(token);
    return false;
  }
  return true;
}
function requireAdmin(req, res, next) {
  if (!isAdmin(req)) return res.status(401).json({ error: 'Sesi admin tidak berlaku. Silakan login kembali.' });
  next();
}
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, hash] = String(stored || '').split(':');
  if (!salt || !hash) return false;
  const actual = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'RIDWAN SHOP API' }));

app.get('/api/toko-data', async (req, res) => {
  try {
    const data = await readData();
    res.set('Cache-Control', 'no-store');
    if (isAdmin(req)) return res.json({ ...data, isAdmin: true, revision: data._revision });
    const { products, storeName, storeLogo, storeAddress, storePhone, storeMapCoord, _revision } = data;
    return res.json({ products, storeName, storeLogo, storeAddress, storePhone, storeMapCoord, isAdmin: false, revision: _revision });
  } catch (error) {
    console.error(error);
    res.status(502).json({ error: 'Tidak dapat mengambil data toko dari penyimpanan cloud.' });
  }
});

app.post('/api/admin/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }), async (req, res) => {
  const username = String(req.body?.username || '');
  const password = String(req.body?.password || '');
  if (username !== 'admin') return res.status(401).json({ error: 'Username atau password salah.' });
  try {
    const data = await readData();
    const valid = data.adminPasswordHash
      ? verifyPassword(password, data.adminPasswordHash)
      : (password.length === ADMIN_PASSWORD.length && crypto.timingSafeEqual(Buffer.from(password), Buffer.from(ADMIN_PASSWORD)));
    if (!valid) return res.status(401).json({ error: 'Username atau password salah.' });
    const token = crypto.randomBytes(32).toString('hex');
    sessions.set(token, Date.now() + SESSION_TTL);
    res.json({ token, expiresIn: SESSION_TTL });
  } catch (error) {
    console.error(error);
    res.status(502).json({ error: 'Login gagal karena penyimpanan cloud tidak dapat dihubungi.' });
  }
});

app.post('/api/admin/logout', (req, res) => {
  sessions.delete(tokenFrom(req));
  res.json({ ok: true });
});

app.put('/api/toko-data', requireAdmin, async (req, res) => {
  const payload = req.body || {};
  const baseRevision = Number(payload.baseRevision);
  if (!Number.isInteger(baseRevision)) return res.status(400).json({ error: 'baseRevision wajib dikirim.' });
  try {
    const result = await mutateData(async latest => {
      if (baseRevision !== latest._revision) {
        const err = new Error('Data toko telah berubah dari perangkat lain. Muat ulang data terbaru sebelum menyimpan.');
        err.status = 409;
        throw err;
      }
      const allowed = ['products', 'orders', 'finance', 'trashBin', 'storeName', 'storeLogo', 'storeAddress', 'storePhone', 'storeMapCoord'];
      for (const key of allowed) if (Object.prototype.hasOwnProperty.call(payload, key)) latest[key] = payload[key];
      return latest;
    });
    res.json({ ok: true, revision: result._revision });
  } catch (error) {
    console.error(error);
    res.status(error.status || 502).json({ error: error.message || 'Gagal menyimpan data.' });
  }
});

app.post('/api/orders', rateLimit({ windowMs: 10 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }), async (req, res) => {
  const order = req.body?.order;
  if (!order || !order.productId || !Number.isInteger(Number(order.qty)) || Number(order.qty) < 1 || Number(order.qty) > 100) {
    return res.status(400).json({ error: 'Detail pesanan tidak valid.' });
  }
  if (!String(order.buyerName || '').trim() || !String(order.buyerPhone || '').trim() || !String(order.buyerAddress || '').trim()) {
    return res.status(400).json({ error: 'Nama, nomor HP, dan alamat wajib diisi.' });
  }
  try {
    const result = await mutateData(async latest => {
      const product = latest.products.find(p => String(p.id) === String(order.productId));
      const qty = Number(order.qty);
      if (!product) { const e = new Error('Produk tidak ditemukan. Muat ulang halaman.'); e.status = 404; throw e; }
      if (Number(product.stock) < qty) { const e = new Error('Stok tidak mencukupi. Silakan muat ulang halaman.'); e.status = 409; throw e; }
      const totalPrice = Number(product.price) * qty;
      const savedOrder = {
        id: String(order.id || `RS-${Date.now()}`), date: new Date().toLocaleDateString('id-ID'),
        buyerName: String(order.buyerName).trim().slice(0, 100),
        buyerPhone: String(order.buyerPhone).trim().slice(0, 30),
        buyerAddress: String(order.buyerAddress).trim().slice(0, 500),
        productName: `${product.name} x ${qty} [${String(order.paymentMethod || 'COD').slice(0, 20)}]`,
        qty, totalPrice, status: 'Pesanan Dikirim Ke WA'
      };
      product.stock = Number(product.stock) - qty;
      latest.orders.unshift(savedOrder);
      latest.finance.unshift({ id: `F${Date.now()}`, date: savedOrder.date, desc: `Penjualan #${savedOrder.id} (${product.name})`, type: 'income', amount: totalPrice });
      return latest;
    });
    res.json({ ok: true, revision: result._revision, data: { products: result.products } });
  } catch (error) {
    console.error(error);
    res.status(error.status || 502).json({ error: error.message || 'Pesanan gagal disimpan.' });
  }
});

app.post('/api/admin/password', requireAdmin, async (req, res) => {
  const password = String(req.body?.password || '');
  if (password.length < 12) return res.status(400).json({ error: 'Password baru minimal 12 karakter.' });
  try {
    const result = await mutateData(async latest => {
      latest.adminPasswordHash = hashPassword(password);
      return latest;
    });
    res.json({ ok: true, revision: result._revision });
  } catch (error) {
    console.error(error);
    res.status(502).json({ error: 'Gagal memperbarui password admin.' });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`RIDWAN SHOP running on port ${PORT}`));
